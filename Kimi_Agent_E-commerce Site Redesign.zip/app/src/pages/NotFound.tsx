import { Link } from "react-router";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <main className="min-h-screen bg-[var(--charcoal)] flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="font-display text-6xl text-[var(--gold)] mb-4">404</h1>
        <p className="text-[var(--cream)] text-xl mb-2">Page Not Found</p>
        <p className="text-[var(--cream-muted)] mb-8">
          The page you are looking for does not exist.
        </p>
        <Link to="/" className="btn-primary inline-flex items-center gap-2">
          <ArrowLeft size={16} /> Back to Home
        </Link>
      </div>
    </main>
  );
}
