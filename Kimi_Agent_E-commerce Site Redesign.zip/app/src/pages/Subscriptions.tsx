import { Link } from "react-router";
import { Coffee, Truck, RotateCcw, Calendar, ArrowRight } from "lucide-react";
import Footer from "@/sections/Footer";

const plans = [
  {
    name: "Explorer",
    price: 249,
    period: "month",
    description: "Perfect for trying different origins",
    features: ["250g per delivery", "1 coffee variety", "Free shipping", "Monthly delivery"],
  },
  {
    name: "Enthusiast",
    price: 449,
    period: "month",
    description: "Our most popular plan",
    features: ["500g per delivery", "2 coffee varieties", "Free shipping", "Bi-weekly delivery", "10% savings"],
    popular: true,
  },
  {
    name: "Connoisseur",
    price: 799,
    period: "month",
    description: "For the true coffee lover",
    features: ["1kg per delivery", "3 coffee varieties", "Free shipping", "Weekly delivery", "15% savings", "Exclusive access"],
  },
];

export default function Subscriptions() {
  return (
    <main className="min-h-screen bg-[var(--charcoal)] pt-20">
      {/* Hero */}
      <div className="py-20 text-center">
        <div className="max-w-3xl mx-auto px-4 sm:px-6">
          <span className="text-[var(--gold)] text-xs uppercase tracking-[0.15em]">Subscriptions</span>
          <h1 className="font-display text-4xl sm:text-5xl text-[var(--cream)] mt-3 mb-4">
            Never Run Out of Great Coffee
          </h1>
          <p className="text-[var(--cream-muted)] leading-relaxed max-w-xl mx-auto">
            Freshly roasted East African coffee delivered to your door on your schedule. 
            Save up to 15% and enjoy free shipping on every delivery.
          </p>
        </div>
      </div>

      {/* Benefits */}
      <div className="py-12 bg-[var(--charcoal-light)]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="grid sm:grid-cols-3 gap-8">
            {[
              { icon: Coffee, title: "Freshly Roasted", desc: "Roasted to order and shipped within 48 hours" },
              { icon: Truck, title: "Free Shipping", desc: "Always free, always tracked, always on time" },
              { icon: RotateCcw, title: "Flexible", desc: "Pause, skip, or cancel anytime - no questions" },
            ].map((item) => (
              <div key={item.title} className="text-center">
                <div className="w-14 h-14 rounded-full border border-[var(--gold)]/30 flex items-center justify-center mx-auto mb-4">
                  <item.icon size={24} className="text-[var(--gold)]" />
                </div>
                <h3 className="text-[var(--cream)] font-medium mb-2">{item.title}</h3>
                <p className="text-[var(--cream-muted)] text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Plans */}
      <div className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h2 className="font-display text-3xl text-[var(--cream)] text-center mb-12">
            Choose Your Plan
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative rounded-lg p-8 border ${
                  plan.popular
                    ? "border-[var(--gold)] bg-[var(--charcoal-light)]"
                    : "border-[var(--cream-muted)]/10 bg-[var(--charcoal-light)]"
                }`}
              >
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[var(--gold)] text-[var(--charcoal)] text-xs uppercase tracking-wider px-4 py-1 rounded-full font-medium">
                    Most Popular
                  </span>
                )}
                <h3 className="font-display text-2xl text-[var(--cream)] mb-2">{plan.name}</h3>
                <p className="text-[var(--cream-muted)] text-sm mb-4">{plan.description}</p>
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="font-display text-4xl text-[var(--gold)]">{plan.price}</span>
                  <span className="text-[var(--cream-muted)]">kr / {plan.period}</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-[var(--cream-muted)]">
                      <Calendar size={14} className="text-[var(--gold)] shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link
                  to="/shop"
                  className={`w-full block text-center py-3 rounded-lg font-medium text-sm uppercase tracking-wider transition-all ${
                    plan.popular
                      ? "bg-[var(--gold)] text-[var(--charcoal)] hover:bg-[var(--gold-bright)]"
                      : "border border-[var(--gold)] text-[var(--gold)] hover:bg-[var(--gold)]/10"
                  }`}
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="py-16 bg-[var(--warm-brown)] text-center">
        <div className="max-w-2xl mx-auto px-4 sm:px-6">
          <h2 className="font-display text-3xl text-[var(--cream)] mb-4">
            Not Sure Which Plan?
          </h2>
          <p className="text-[var(--cream-muted)] mb-6">
            Start with a one-time purchase and upgrade to a subscription anytime. 
            All our coffees are available for both single purchase and subscription.
          </p>
          <Link to="/shop" className="btn-primary inline-flex items-center gap-2">
            Browse All Coffee <ArrowRight size={16} />
          </Link>
        </div>
      </div>

      <Footer />
    </main>
  );
}
