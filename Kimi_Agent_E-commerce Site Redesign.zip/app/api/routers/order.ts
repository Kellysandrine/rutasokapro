import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { orders, orderItems, cartItems, products } from "@db/schema";
import { eq, desc, sql, and } from "drizzle-orm";

export const orderRouter = createRouter({
  create: publicQuery
    .input(z.object({
      sessionId: z.string(),
      customerEmail: z.string().email(),
      customerName: z.string().optional(),
      shippingAddress: z.object({
        street: z.string(),
        city: z.string(),
        postalCode: z.string(),
        country: z.string(),
      }).optional(),
      billingAddress: z.object({
        street: z.string(),
        city: z.string(),
        postalCode: z.string(),
        country: z.string(),
      }).optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }: { input: any }) => {
      const db = getDb();

      const cart = await db
        .select({
          cartItem: cartItems,
          product: products,
        })
        .from(cartItems)
        .innerJoin(products, eq(cartItems.productId, products.id))
        .where(eq(cartItems.sessionId, input.sessionId));

      if (cart.length === 0) {
        throw new Error("Cart is empty");
      }

      const subtotal = cart.reduce((sum: number, item: any) => {
        return sum + Number(item.product.price) * item.cartItem.quantity;
      }, 0);
      const shipping = subtotal > 500 ? 0 : 49;
      const total = subtotal + shipping;

      const orderNumber = `RUT-${Date.now().toString(36).toUpperCase()}`;

      const orderResult = await db.insert(orders).values({
        orderNumber,
        sessionId: input.sessionId,
        status: "pending",
        subtotal: subtotal.toString(),
        shipping: shipping.toString(),
        total: total.toString(),
        currency: "SEK",
        customerEmail: input.customerEmail,
        customerName: input.customerName,
        shippingAddress: input.shippingAddress,
        billingAddress: input.billingAddress,
        notes: input.notes,
      });

      const orderId = Number(orderResult[0].insertId);

      for (const item of cart) {
        await db.insert(orderItems).values({
          orderId,
          productId: item.product.id,
          productName: item.product.name,
          price: item.product.price,
          quantity: item.cartItem.quantity,
          total: (Number(item.product.price) * item.cartItem.quantity).toString(),
        });
      }

      await db.delete(cartItems).where(eq(cartItems.sessionId, input.sessionId));

      return { orderNumber, total, status: "pending" };
    }),

  getByNumber: publicQuery
    .input(z.object({ orderNumber: z.string() }))
    .query(async ({ input }: { input: { orderNumber: string } }) => {
      const db = getDb();
      const order = await db
        .select()
        .from(orders)
        .where(eq(orders.orderNumber, input.orderNumber))
        .limit(1);

      if (!order[0]) return null;

      const items = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.orderId, order[0].id));

      return { ...order[0], items };
    }),

  listAdmin: adminQuery
    .input(z.object({
      page: z.number().default(1),
      limit: z.number().default(20),
      status: z.string().optional(),
      search: z.string().optional(),
    }).optional())
    .query(async ({ input }: { input: any }) => {
      const db = getDb();
      const { page = 1, limit = 20, status, search } = input || {};
      const offset = (page - 1) * limit;

      const conditions: any[] = [];
      if (status) conditions.push(eq(orders.status, status));
      if (search) {
        conditions.push(
          sql`${orders.orderNumber} LIKE ${`%${search}%`} OR ${orders.customerEmail} LIKE ${`%${search}%`}`
        );
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const items = await db
        .select()
        .from(orders)
        .where(where)
        .orderBy(desc(orders.createdAt))
        .limit(limit)
        .offset(offset);

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(orders)
        .where(where);

      return {
        items,
        total: countResult[0]?.count || 0,
        page,
        pages: Math.ceil((countResult[0]?.count || 0) / limit),
      };
    }),

  updateStatus: adminQuery
    .input(z.object({
      orderId: z.number(),
      status: z.enum(["pending", "processing", "shipped", "delivered", "cancelled"]),
    }))
    .mutation(async ({ input }: { input: { orderId: number; status: string } }) => {
      const db = getDb();
      await db
        .update(orders)
        .set({ status: input.status as any })
        .where(eq(orders.id, input.orderId));
      return { success: true };
    }),
});
