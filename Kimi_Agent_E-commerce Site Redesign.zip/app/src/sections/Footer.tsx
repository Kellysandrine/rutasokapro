import { Link } from "react-router";
import { Facebook, Instagram, Linkedin, MapPin, Phone, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[var(--charcoal-light)] border-t border-[var(--cream-muted)]/8">
      {/* Newsletter */}
      <div className="py-16 border-b border-[var(--cream-muted)]/8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-xl mx-auto text-center">
            <h3 className="font-display text-2xl sm:text-3xl text-[var(--cream)] mb-2">
              Join the Coffee Circle
            </h3>
            <p className="text-[var(--cream-muted)] text-sm mb-6">
              Enter your email address here and receive offers, news and inspiration.
            </p>
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                alert("Thank you for subscribing!");
              }}
            >
              <input
                type="email"
                placeholder="Email address"
                className="flex-1 bg-[var(--charcoal)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50 text-sm"
                required
              />
              <button type="submit" className="btn-primary shrink-0">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Brand */}
            <div>
              <Link to="/" className="inline-block">
                <span className="font-display text-2xl tracking-[0.2em] text-[var(--cream)]">
                  RUTASOKA
                </span>
              </Link>
              <p className="text-[var(--cream-muted)] text-sm mt-4 leading-relaxed">
                Premium East African coffee, sourced with integrity and roasted with passion. 
                A cup that makes a difference.
              </p>
              <div className="flex items-center gap-3 mt-4">
                <a href="#" className="w-9 h-9 rounded-full border border-[var(--cream-muted)]/20 flex items-center justify-center text-[var(--cream-muted)] hover:text-[var(--gold)] hover:border-[var(--gold)] transition-colors">
                  <Facebook size={16} />
                </a>
                <a href="#" className="w-9 h-9 rounded-full border border-[var(--cream-muted)]/20 flex items-center justify-center text-[var(--cream-muted)] hover:text-[var(--gold)] hover:border-[var(--gold)] transition-colors">
                  <Instagram size={16} />
                </a>
                <a href="#" className="w-9 h-9 rounded-full border border-[var(--cream-muted)]/20 flex items-center justify-center text-[var(--cream-muted)] hover:text-[var(--gold)] hover:border-[var(--gold)] transition-colors">
                  <Linkedin size={16} />
                </a>
              </div>
            </div>

            {/* Shop */}
            <div>
              <h4 className="text-[var(--cream)] text-sm font-medium uppercase tracking-wider mb-4">
                Shop
              </h4>
              <ul className="space-y-3">
                <li><Link to="/shop" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">All Coffee</Link></li>
                <li><Link to="/shop?beanType=whole-bean" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">Whole Beans</Link></li>
                <li><Link to="/shop?beanType=ground" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">Ground Coffee</Link></li>
                <li><Link to="/shop?roastLevel=espresso" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">Espresso</Link></li>
                <li><Link to="/subscriptions" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">Subscriptions</Link></li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-[var(--cream)] text-sm font-medium uppercase tracking-wider mb-4">
                Rutasoka
              </h4>
              <ul className="space-y-3">
                <li><Link to="/about" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">About Us</Link></li>
                <li><Link to="/about#impact" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">Our Impact</Link></li>
                <li><Link to="/about#sustainability" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">Sustainability</Link></li>
                <li><Link to="/contact" className="text-[var(--cream-muted)] text-sm hover:text-[var(--gold)] transition-colors">Contact</Link></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-[var(--cream)] text-sm font-medium uppercase tracking-wider mb-4">
                Contact
              </h4>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-[var(--cream-muted)] text-sm">
                  <MapPin size={16} className="shrink-0 mt-0.5" />
                  <span>Import Street 20, 422 46 Hisings Backa, Sweden</span>
                </li>
                <li className="flex items-center gap-2 text-[var(--cream-muted)] text-sm">
                  <Phone size={16} className="shrink-0" />
                  <span>559111-6941</span>
                </li>
                <li className="flex items-center gap-2 text-[var(--cream-muted)] text-sm">
                  <Mail size={16} className="shrink-0" />
                  <span>hello@rutasoka.com</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom */}
          <div className="mt-12 pt-8 border-t border-[var(--cream-muted)]/8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-[var(--cream-muted)]/60 text-xs">
              &copy; {new Date().getFullYear()} Rutasoka Coffee. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <Link to="/privacy" className="text-[var(--cream-muted)]/60 text-xs hover:text-[var(--gold)] transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-[var(--cream-muted)]/60 text-xs hover:text-[var(--gold)] transition-colors">
                Terms of Purchase
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
