import { useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { LogIn, UserPlus, ArrowLeft, Coffee } from "lucide-react";
import { toast } from "sonner";

function getOAuthUrl() {
  const authUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${authUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    displayName: "",
  });

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      toast.success("Signed in successfully!");
      window.location.href = "/";
    },
    onError: (err) => toast.error(err.message),
  });

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      toast.success("Account created successfully!");
      window.location.href = "/";
    },
    onError: (err) => toast.error(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === "login") {
      loginMutation.mutate({ username: form.username, password: form.password });
    } else {
      registerMutation.mutate({
        username: form.username,
        email: form.email,
        password: form.password,
        displayName: form.displayName || undefined,
      });
    }
  };

  return (
    <main className="min-h-screen bg-[var(--charcoal)] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-[var(--cream-muted)] hover:text-[var(--gold)] mb-8">
          <ArrowLeft size={16} /> Back to Store
        </Link>

        <div className="text-center mb-8">
          <Coffee size={40} className="mx-auto text-[var(--gold)] mb-4" />
          <h1 className="font-display text-3xl text-[var(--cream)]">
            {mode === "login" ? "Welcome Back" : "Create Account"}
          </h1>
          <p className="text-[var(--cream-muted)] text-sm mt-2">
            {mode === "login" ? "Sign in to your account" : "Join the Rutasoka family"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Username *"
            required
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
          />

          {mode === "register" && (
            <>
              <input
                type="email"
                placeholder="Email *"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
              />
              <input
                type="text"
                placeholder="Display Name (optional)"
                value={form.displayName}
                onChange={(e) => setForm({ ...form, displayName: e.target.value })}
                className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
              />
            </>
          )}

          <input
            type="password"
            placeholder="Password *"
            required
            minLength={6}
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
          />

          <button
            type="submit"
            disabled={loginMutation.isPending || registerMutation.isPending}
            className="btn-primary w-full disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {mode === "login" ? (
              <><LogIn size={18} /> {loginMutation.isPending ? "Signing in..." : "Sign In"}</>
            ) : (
              <><UserPlus size={18} /> {registerMutation.isPending ? "Creating..." : "Create Account"}</>
            )}
          </button>
        </form>

        <div className="my-6 flex items-center gap-4">
          <div className="flex-1 h-px bg-[var(--cream-muted)]/10" />
          <span className="text-xs text-[var(--cream-muted)] uppercase">or</span>
          <div className="flex-1 h-px bg-[var(--cream-muted)]/10" />
        </div>

        <a
          href={getOAuthUrl()}
          className="btn-secondary w-full flex items-center justify-center gap-2"
        >
          Sign in with Portal
        </a>

        <p className="text-center text-sm text-[var(--cream-muted)] mt-6">
          {mode === "login" ? (
            <>Don&apos;t have an account? <button onClick={() => setMode("register")} className="text-[var(--gold)] hover:underline">Create one</button></>
          ) : (
            <>Already have an account? <button onClick={() => setMode("login")} className="text-[var(--gold)] hover:underline">Sign in</button></>
          )}
        </p>
      </div>
    </main>
  );
}
