import { X, Minus, Plus, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/store/cartStore";
import { trpc } from "@/providers/trpc";
import { Link } from "react-router";
import { toast } from "sonner";

export default function CartDrawer() {
  const { isOpen, setCartOpen, items, sessionId } = useCartStore();
  const utils = trpc.useUtils();

  const updateMutation = trpc.cart.updateQuantity.useMutation({
    onSuccess: () => utils.cart.get.invalidate({ sessionId }),
  });
  const removeMutation = trpc.cart.remove.useMutation({
    onSuccess: () => {
      utils.cart.get.invalidate({ sessionId });
      toast.success("Item removed from cart");
    },
  });

  const subtotal = items.reduce((sum, i) => sum + i.lineTotal, 0);
  const shipping = subtotal > 500 ? 0 : 49;
  const total = subtotal + shipping;

  const updateQty = (itemId: number, newQty: number) => {
    if (newQty <= 0) {
      removeMutation.mutate({ sessionId, itemId });
      return;
    }
    updateMutation.mutate({ sessionId, itemId, quantity: newQty });
    // Optimistic update
    useCartStore.getState().updateQuantity(itemId, newQty);
  };

  const removeItem = (itemId: number) => {
    removeMutation.mutate({ sessionId, itemId });
    useCartStore.getState().removeItem(itemId);
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-50"
          onClick={() => setCartOpen(false)}
        />
      )}

      {/* Drawer */}
      <div
        className={`fixed top-0 right-0 h-full w-full sm:w-[420px] bg-[#1A1714] border-l border-[var(--cream-muted)]/10 z-50 transform transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-[var(--cream-muted)]/10">
            <h2 className="font-display text-xl text-[var(--cream)]">
              Your Bag ({items.length})
            </h2>
            <button
              onClick={() => setCartOpen(false)}
              className="text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          {/* Items */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <ShoppingBag size={48} className="text-[var(--cream-muted)]/30 mb-4" />
                <p className="text-[var(--cream-muted)]">Your bag is empty</p>
                <Link
                  to="/shop"
                  onClick={() => setCartOpen(false)}
                  className="mt-4 text-[var(--gold)] hover:underline text-sm"
                >
                  Start Shopping
                </Link>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 bg-[var(--charcoal-light)] rounded-lg p-3"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded-md shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm text-[var(--cream)] truncate font-body">
                      {item.product.name}
                    </h3>
                    <p className="text-xs text-[var(--cream-muted)] mt-0.5">
                      {item.product.weight}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQty(item.id, item.quantity - 1)}
                          className="w-6 h-6 rounded border border-[var(--cream-muted)]/20 flex items-center justify-center text-[var(--cream-muted)] hover:border-[var(--gold)] hover:text-[var(--gold)] transition-colors"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="text-sm text-[var(--cream)] w-4 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQty(item.id, item.quantity + 1)}
                          className="w-6 h-6 rounded border border-[var(--cream-muted)]/20 flex items-center justify-center text-[var(--cream-muted)] hover:border-[var(--gold)] hover:text-[var(--gold)] transition-colors"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-[var(--gold)] font-medium">
                          {item.lineTotal.toFixed(2)} kr
                        </span>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="text-[var(--cream-muted)] hover:text-red-400 transition-colors"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          {items.length > 0 && (
            <div className="p-6 border-t border-[var(--cream-muted)]/10 space-y-4">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-[var(--cream-muted)]">
                  <span>Subtotal</span>
                  <span>{subtotal.toFixed(2)} kr</span>
                </div>
                <div className="flex justify-between text-[var(--cream-muted)]">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? "Free" : `${shipping.toFixed(2)} kr`}</span>
                </div>
                <div className="flex justify-between text-[var(--cream)] font-medium pt-2 border-t border-[var(--cream-muted)]/10">
                  <span>Total</span>
                  <span className="text-[var(--gold)]">{total.toFixed(2)} kr</span>
                </div>
                {shipping > 0 && (
                  <p className="text-xs text-[var(--cream-muted)]/60">
                    Free shipping on orders over 500 kr
                  </p>
                )}
              </div>
              <Link
                to="/checkout"
                onClick={() => setCartOpen(false)}
                className="btn-primary w-full block text-center"
              >
                Checkout
              </Link>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
