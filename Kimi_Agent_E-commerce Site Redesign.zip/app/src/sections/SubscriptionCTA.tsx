import { Link } from "react-router";
import { Coffee, Truck, RotateCcw } from "lucide-react";

export default function SubscriptionCTA() {
  return (
    <section className="py-24 bg-[var(--warm-brown)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
        <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[var(--cream)] mb-4">
          Never Run Out of Great Coffee
        </h2>
        <p className="text-[var(--cream-muted)] max-w-2xl mx-auto mb-10 leading-relaxed">
          Join our coffee subscription and enjoy freshly roasted East African coffee delivered 
          to your door. Save up to 15% on every order, with free shipping and flexible delivery schedules.
        </p>

        <div className="grid sm:grid-cols-3 gap-8 mb-10 max-w-3xl mx-auto">
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full border border-[var(--gold)]/30 flex items-center justify-center mb-3">
              <Coffee size={20} className="text-[var(--gold)]" />
            </div>
            <p className="text-[var(--cream)] text-sm font-medium">Freshly Roasted</p>
            <p className="text-[var(--cream-muted)] text-xs mt-1">Roasted to order</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full border border-[var(--gold)]/30 flex items-center justify-center mb-3">
              <Truck size={20} className="text-[var(--gold)]" />
            </div>
            <p className="text-[var(--cream)] text-sm font-medium">Free Shipping</p>
            <p className="text-[var(--cream-muted)] text-xs mt-1">On all subscriptions</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full border border-[var(--gold)]/30 flex items-center justify-center mb-3">
              <RotateCcw size={20} className="text-[var(--gold)]" />
            </div>
            <p className="text-[var(--cream)] text-sm font-medium">Flexible</p>
            <p className="text-[var(--cream-muted)] text-xs mt-1">Pause anytime</p>
          </div>
        </div>

        <Link to="/subscriptions" className="btn-primary">
          Start a Subscription
        </Link>
        <p className="mt-4 text-sm text-[var(--cream-muted)]">
          <Link to="/subscriptions" className="text-[var(--gold)] hover:underline">
            See How It Works
          </Link>
        </p>
      </div>
    </section>
  );
}
