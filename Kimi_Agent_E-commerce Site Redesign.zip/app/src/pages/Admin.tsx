import { useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Package, ShoppingCart, TrendingUp, Search, ArrowLeft, Eye } from "lucide-react";

export default function Admin() {
  const { user, isAdmin, isLoading } = useAuth();
  const [orderSearch, setOrderSearch] = useState("");
  const [orderPage, setOrderPage] = useState(1);
  const [productSearch, setProductSearch] = useState("");
  const [productPage, setProductPage] = useState(1);
  const [activeTab, setActiveTab] = useState<"orders" | "products">("orders");

  const { data: ordersData, isLoading: ordersLoading } = trpc.order.listAdmin.useQuery(
    { page: orderPage, limit: 10, search: orderSearch || undefined },
    { enabled: isAdmin }
  );

  const { data: productsData, isLoading: productsLoading } = trpc.product.listAdmin.useQuery(
    { page: productPage, limit: 10, search: productSearch || undefined },
    { enabled: isAdmin }
  );

  const updateStatus = trpc.order.updateStatus.useMutation({
    onSuccess: () => {
      trpc.useUtils().order.listAdmin.invalidate();
    },
  });

  if (isLoading) {
    return <div className="min-h-screen bg-[var(--charcoal)] pt-20 flex items-center justify-center text-[var(--gold)]">Loading...</div>;
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[var(--charcoal)] pt-20 flex items-center justify-center">
        <div className="text-center">
          <p className="text-[var(--cream-muted)] mb-4">Please sign in to access the admin dashboard</p>
          <Link to="/login" className="btn-primary">Sign In</Link>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[var(--charcoal)] pt-20 flex items-center justify-center">
        <div className="text-center">
          <p className="text-[var(--cream-muted)] mb-4">You don&apos;t have admin access</p>
          <Link to="/" className="btn-primary">Go Home</Link>
        </div>
      </div>
    );
  }

  const stats = [
    { label: "Total Orders", value: ordersData?.total || 0, icon: ShoppingCart },
    { label: "Products", value: productsData?.total || 0, icon: Package },
    { label: "Pending", value: ordersData?.items.filter((o: any) => o.status === "pending").length || 0, icon: TrendingUp },
  ];

  return (
    <main className="min-h-screen bg-[var(--charcoal)] pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-[var(--cream-muted)] hover:text-[var(--gold)] mb-6">
          <ArrowLeft size={16} /> Back to Store
        </Link>

        <div className="flex items-center justify-between mb-8">
          <h1 className="font-display text-3xl text-[var(--cream)]">Admin Dashboard</h1>
          <span className="text-sm text-[var(--cream-muted)]">Welcome, {user.name}</span>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-[var(--charcoal-light)] rounded-lg p-6 border border-[var(--cream-muted)]/8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[var(--cream-muted)] text-sm">{stat.label}</p>
                  <p className="font-display text-3xl text-[var(--gold)] mt-1">{stat.value}</p>
                </div>
                <stat.icon size={24} className="text-[var(--cream-muted)]/30" />
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-6 border-b border-[var(--cream-muted)]/10 mb-6">
          {(["orders", "products"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-3 text-sm uppercase tracking-wider transition-colors relative ${
                activeTab === tab ? "text-[var(--gold)]" : "text-[var(--cream-muted)] hover:text-[var(--cream)]"
              }`}
            >
              {tab === "orders" ? "Orders" : "Products"}
              {activeTab === tab && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--gold)]" />}
            </button>
          ))}
        </div>

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="relative flex-1 max-w-sm">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--cream-muted)]" />
                <input
                  type="text"
                  placeholder="Search orders..."
                  value={orderSearch}
                  onChange={(e) => { setOrderSearch(e.target.value); setOrderPage(1); }}
                  className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] pl-10 pr-4 py-2 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50 text-sm"
                />
              </div>
            </div>

            {ordersLoading ? (
              <div className="text-[var(--cream-muted)]">Loading orders...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[var(--cream-muted)]/10">
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Order</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Customer</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Total</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Status</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Date</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ordersData?.items.map((order: any) => (
                      <tr key={order.id} className="border-b border-[var(--cream-muted)]/5">
                        <td className="py-3 pr-4 text-sm text-[var(--gold)]">{order.orderNumber}</td>
                        <td className="py-3 pr-4 text-sm text-[var(--cream)]">{order.customerName || order.customerEmail}</td>
                        <td className="py-3 pr-4 text-sm text-[var(--cream)]">{Number(order.total).toFixed(2)} kr</td>
                        <td className="py-3 pr-4">
                          <select
                            value={order.status}
                            onChange={(e) => updateStatus.mutate({ orderId: order.id, status: e.target.value as any })}
                            className={`text-xs uppercase tracking-wider px-2 py-1 rounded border-0 ${
                              order.status === "pending" ? "bg-yellow-500/20 text-yellow-400" :
                              order.status === "processing" ? "bg-blue-500/20 text-blue-400" :
                              order.status === "shipped" ? "bg-purple-500/20 text-purple-400" :
                              order.status === "delivered" ? "bg-green-500/20 text-green-400" :
                              "bg-red-500/20 text-red-400"
                            }`}
                          >
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </td>
                        <td className="py-3 pr-4 text-sm text-[var(--cream-muted)]">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3">
                          <button className="text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors">
                            <Eye size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {ordersData && ordersData.pages > 1 && (
                  <div className="flex items-center gap-2 mt-6">
                    <button onClick={() => setOrderPage(Math.max(1, orderPage - 1))} disabled={orderPage === 1} className="px-3 py-1 bg-[var(--charcoal-light)] rounded text-sm text-[var(--cream-muted)] disabled:opacity-30">Prev</button>
                    <span className="text-sm text-[var(--cream-muted)]">Page {orderPage} of {ordersData.pages}</span>
                    <button onClick={() => setOrderPage(Math.min(ordersData.pages, orderPage + 1))} disabled={orderPage === ordersData.pages} className="px-3 py-1 bg-[var(--charcoal-light)] rounded text-sm text-[var(--cream-muted)] disabled:opacity-30">Next</button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Products Tab */}
        {activeTab === "products" && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="relative flex-1 max-w-sm">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--cream-muted)]" />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={productSearch}
                  onChange={(e) => { setProductSearch(e.target.value); setProductPage(1); }}
                  className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] pl-10 pr-4 py-2 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50 text-sm"
                />
              </div>
            </div>

            {productsLoading ? (
              <div className="text-[var(--cream-muted)]">Loading products...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[var(--cream-muted)]/10">
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Product</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Origin</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Price</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3 pr-4">Stock</th>
                      <th className="text-left text-xs uppercase tracking-wider text-[var(--cream-muted)] pb-3">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {productsData?.items.map((product: any) => (
                      <tr key={product.id} className="border-b border-[var(--cream-muted)]/5">
                        <td className="py-3 pr-4">
                          <div className="flex items-center gap-3">
                            <img src={product.image} alt={product.name} className="w-10 h-10 object-cover rounded" />
                            <span className="text-sm text-[var(--cream)]">{product.name}</span>
                          </div>
                        </td>
                        <td className="py-3 pr-4 text-sm text-[var(--cream-muted)]">{product.origin}</td>
                        <td className="py-3 pr-4 text-sm text-[var(--gold)]">{Number(product.price).toFixed(2)} kr</td>
                        <td className="py-3 pr-4 text-sm text-[var(--cream)]">{product.stock}</td>
                        <td className="py-3">
                          <span className={`text-xs px-2 py-1 rounded ${product.isActive ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                            {product.isActive ? "Active" : "Inactive"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {productsData && productsData.pages > 1 && (
                  <div className="flex items-center gap-2 mt-6">
                    <button onClick={() => setProductPage(Math.max(1, productPage - 1))} disabled={productPage === 1} className="px-3 py-1 bg-[var(--charcoal-light)] rounded text-sm text-[var(--cream-muted)] disabled:opacity-30">Prev</button>
                    <span className="text-sm text-[var(--cream-muted)]">Page {productPage} of {productsData.pages}</span>
                    <button onClick={() => setProductPage(Math.min(productsData.pages, productPage + 1))} disabled={productPage === productsData.pages} className="px-3 py-1 bg-[var(--charcoal-light)] rounded text-sm text-[var(--cream-muted)] disabled:opacity-30">Next</button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}
