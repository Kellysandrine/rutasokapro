import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { products, categories } from "@db/schema";
import { eq, like, and, sql, desc } from "drizzle-orm";

export const productRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        categorySlug: z.string().optional(),
        roastLevel: z.string().optional(),
        beanType: z.string().optional(),
        origin: z.string().optional(),
        search: z.string().optional(),
        sort: z.string().default("name"),
        page: z.number().default(1),
        limit: z.number().default(12),
      }).optional()
    )
    .query(async ({ input }: { input: any }) => {
      const db = getDb();
      const params = input || {};
      const { categorySlug, roastLevel, beanType, origin, search, sort, page, limit } = params;

      const conditions: any[] = [];
      conditions.push(eq(products.isActive, true));

      if (roastLevel) conditions.push(eq(products.roastLevel, roastLevel));
      if (beanType) conditions.push(eq(products.beanType, beanType));
      if (origin) conditions.push(like(products.origin, `%${origin}%`));
      if (search) {
        conditions.push(
          sql`${products.name} LIKE ${`%${search}%`} OR ${products.origin} LIKE ${`%${search}%`}`
        );
      }

      if (categorySlug) {
        const cat = await db.select().from(categories).where(eq(categories.slug, categorySlug)).limit(1);
        if (cat.length > 0) {
          conditions.push(eq(products.categoryId, cat[0].id));
        }
      }

      const where = conditions.length > 1 ? and(...conditions) : conditions[0];
      const offset = (page - 1) * limit;

      const orderBy = sort === "price-low" ? products.price : sort === "price-high" ? desc(products.price) : products.name;

      const items = await db
        .select()
        .from(products)
        .where(where)
        .orderBy(orderBy)
        .limit(limit)
        .offset(offset);

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(products)
        .where(where);

      const total = countResult[0]?.count || 0;

      return {
        items,
        total,
        page,
        pages: Math.ceil(total / limit),
      };
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }: { input: { slug: string } }) => {
      const db = getDb();
      const product = await db
        .select()
        .from(products)
        .where(eq(products.slug, input.slug))
        .limit(1);

      if (!product[0]) return null;

      const related = await db
        .select()
        .from(products)
        .where(
          and(
            eq(products.origin, product[0].origin),
            eq(products.isActive, true),
            sql`${products.id} != ${product[0].id}`
          )
        )
        .limit(4);

      return { ...product[0], related };
    }),

  listAdmin: adminQuery
    .input(
      z.object({
        page: z.number().default(1),
        limit: z.number().default(20),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }: { input: any }) => {
      const db = getDb();
      const { page = 1, limit = 20, search } = input || {};
      const offset = (page - 1) * limit;

      let where = undefined;
      if (search) {
        where = like(products.name, `%${search}%`);
      }

      const items = await db.select().from(products).where(where).limit(limit).offset(offset);
      const countResult = await db.select({ count: sql<number>`count(*)` }).from(products).where(where);

      return {
        items,
        total: countResult[0]?.count || 0,
        page,
        pages: Math.ceil((countResult[0]?.count || 0) / limit),
      };
    }),
});
