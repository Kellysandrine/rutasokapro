import { create } from "zustand";

export interface CartItem {
  id: number;
  sessionId: string;
  productId: number;
  quantity: number;
  product: {
    id: number;
    name: string;
    slug: string;
    price: string;
    image: string;
    weight: string;
    origin: string;
    roastLevel: string;
  };
  lineTotal: number;
}

interface CartState {
  items: CartItem[];
  isOpen: boolean;
  sessionId: string;
  setItems: (items: CartItem[]) => void;
  addItem: (item: CartItem) => void;
  removeItem: (itemId: number) => void;
  updateQuantity: (itemId: number, quantity: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
  setCartOpen: (open: boolean) => void;
  getItemCount: () => number;
  getTotal: () => number;
}

function getOrCreateSessionId(): string {
  let sid = localStorage.getItem("rutasoka_session_id");
  if (!sid) {
    sid = "sess_" + Math.random().toString(36).substring(2) + Date.now().toString(36);
    localStorage.setItem("rutasoka_session_id", sid);
  }
  return sid;
}

export const useCartStore = create<CartState>((set, get) => ({
  items: [],
  isOpen: false,
  sessionId: getOrCreateSessionId(),

  setItems: (items) => set({ items }),

  addItem: (item) => {
    const { items } = get();
    const existing = items.find((i) => i.productId === item.productId);
    if (existing) {
      set({
        items: items.map((i) =>
          i.productId === item.productId
            ? { ...i, quantity: i.quantity + item.quantity, lineTotal: (i.quantity + item.quantity) * Number(i.product.price) }
            : i
        ),
      });
    } else {
      set({ items: [...items, item] });
    }
  },

  removeItem: (itemId) => {
    set({ items: get().items.filter((i) => i.id !== itemId) });
  },

  updateQuantity: (itemId, quantity) => {
    if (quantity <= 0) {
      set({ items: get().items.filter((i) => i.id !== itemId) });
      return;
    }
    set({
      items: get().items.map((i) =>
        i.id === itemId
          ? { ...i, quantity, lineTotal: quantity * Number(i.product.price) }
          : i
      ),
    });
  },

  clearCart: () => set({ items: [] }),

  toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),

  setCartOpen: (open) => set({ isOpen: open }),

  getItemCount: () => get().items.reduce((sum, i) => sum + i.quantity, 0),

  getTotal: () => get().items.reduce((sum, i) => sum + i.lineTotal, 0),
}));
