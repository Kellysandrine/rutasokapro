import { useCallback } from "react";
import { trpc } from "@/providers/trpc";

export interface UnifiedUser {
  id: number;
  name: string;
  email?: string | null;
  avatar?: string | null;
  role: string;
}

export function useAuth() {
  const utils = trpc.useUtils();
  const { data: oauthUser, isLoading: oauthLoading } = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });
  const { data: localUser, isLoading: localLoading } = trpc.localAuth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      utils.localAuth.me.invalidate();
      window.location.reload();
    },
  });

  const user: UnifiedUser | null = oauthUser
    ? {
        id: oauthUser.id,
        name: oauthUser.name || "User",
        email: oauthUser.email,
        avatar: oauthUser.avatar,
        role: oauthUser.role,
      }
    : localUser
    ? {
        id: localUser.id,
        name: localUser.name || localUser.displayName || localUser.username || "User",
        email: localUser.email,
        avatar: null,
        role: localUser.role,
      }
    : null;

  const isAdmin = user?.role === "admin";
  const isLoading = oauthLoading || localLoading;

  const logout = useCallback(() => {
    localStorage.removeItem("local_auth_token");
    logoutMutation.mutate();
  }, [logoutMutation]);

  return {
    user,
    isAdmin,
    isLoading,
    isAuthenticated: !!user,
    logout,
  };
}
