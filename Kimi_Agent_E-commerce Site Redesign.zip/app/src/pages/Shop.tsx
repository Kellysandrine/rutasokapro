import { useState } from "react";
import { Link, useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { SlidersHorizontal, X } from "lucide-react";
import Footer from "@/sections/Footer";

const roastLevels = [
  { value: "", label: "All Roast Levels" },
  { value: "light", label: "Light" },
  { value: "medium", label: "Medium" },
  { value: "medium-dark", label: "Medium Dark" },
  { value: "dark", label: "Dark" },
  { value: "espresso", label: "Espresso" },
];

const beanTypes = [
  { value: "", label: "All Types" },
  { value: "whole-bean", label: "Whole Beans" },
  { value: "ground", label: "Ground" },
];

const sortOptions = [
  { value: "name", label: "Name A-Z" },
  { value: "price-low", label: "Price: Low to High" },
  { value: "price-high", label: "Price: High to Low" },
];

export default function Shop() {
  const [searchParams] = useSearchParams();
  const urlSearch = searchParams.get("search") || "";
  const urlRoast = searchParams.get("roastLevel") || "";
  const urlBeanType = searchParams.get("beanType") || "";

  const [search, setSearch] = useState(urlSearch);
  const [roastLevel, setRoastLevel] = useState(urlRoast);
  const [beanType, setBeanType] = useState(urlBeanType);
  const [sort, setSort] = useState("name");
  const [page, setPage] = useState(1);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const { data, isLoading } = trpc.product.list.useQuery({
    search: search || undefined,
    roastLevel: roastLevel || undefined,
    beanType: beanType || undefined,
    sort,
    page,
    limit: 12,
  });

  const products = data?.items || [];
  const totalPages = data?.pages || 1;

  const clearFilters = () => {
    setSearch("");
    setRoastLevel("");
    setBeanType("");
    setPage(1);
  };

  const hasFilters = search || roastLevel || beanType;

  return (
    <main className="min-h-screen bg-[var(--charcoal)] pt-20">
      {/* Header */}
      <div className="bg-[var(--charcoal-light)] border-b border-[var(--cream-muted)]/8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <h1 className="font-display text-3xl sm:text-4xl text-[var(--cream)] mb-2">
            Shop Coffee
          </h1>
          <p className="text-[var(--cream-muted)] text-sm">
            {data?.total || 0} products available
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Filters Bar */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center gap-2 px-4 py-2 bg-[var(--charcoal-light)] rounded-lg text-sm text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors border border-[var(--cream-muted)]/10"
          >
            <SlidersHorizontal size={16} />
            Filters
          </button>

          <div className="hidden sm:flex items-center gap-3 ml-auto">
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="bg-[var(--charcoal-light)] text-[var(--cream)] text-sm px-4 py-2 rounded-lg border border-[var(--cream-muted)]/10 focus:border-[var(--gold)] focus:outline-none"
            >
              {sortOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Filter Panel */}
        {filtersOpen && (
          <div className="bg-[var(--charcoal-light)] rounded-lg p-6 mb-8 border border-[var(--cream-muted)]/10">
            <div className="grid sm:grid-cols-3 gap-6">
              <div>
                <label className="text-xs uppercase tracking-wider text-[var(--cream-muted)] mb-2 block">
                  Search
                </label>
                <input
                  type="text"
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                  placeholder="Search products..."
                  className="w-full bg-[var(--charcoal)] text-[var(--cream)] px-4 py-2 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50 text-sm"
                />
              </div>
              <div>
                <label className="text-xs uppercase tracking-wider text-[var(--cream-muted)] mb-2 block">
                  Roast Level
                </label>
                <select
                  value={roastLevel}
                  onChange={(e) => { setRoastLevel(e.target.value); setPage(1); }}
                  className="w-full bg-[var(--charcoal)] text-[var(--cream)] px-4 py-2 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none text-sm"
                >
                  {roastLevels.map((r) => (
                    <option key={r.value} value={r.value}>{r.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs uppercase tracking-wider text-[var(--cream-muted)] mb-2 block">
                  Bean Type
                </label>
                <select
                  value={beanType}
                  onChange={(e) => { setBeanType(e.target.value); setPage(1); }}
                  className="w-full bg-[var(--charcoal)] text-[var(--cream)] px-4 py-2 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none text-sm"
                >
                  {beanTypes.map((b) => (
                    <option key={b.value} value={b.value}>{b.label}</option>
                  ))}
                </select>
              </div>
            </div>
            {hasFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-1 mt-4 text-sm text-[var(--gold)] hover:underline"
              >
                <X size={14} /> Clear all filters
              </button>
            )}
          </div>
        )}

        {/* Active Filters */}
        {hasFilters && !filtersOpen && (
          <div className="flex flex-wrap items-center gap-2 mb-6">
            {search && (
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-[var(--gold)]/10 text-[var(--gold)] text-xs rounded-full">
                Search: {search} <button onClick={() => setSearch("")}><X size={12} /></button>
              </span>
            )}
            {roastLevel && (
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-[var(--gold)]/10 text-[var(--gold)] text-xs rounded-full">
                {roastLevels.find(r => r.value === roastLevel)?.label} <button onClick={() => setRoastLevel("")}><X size={12} /></button>
              </span>
            )}
            {beanType && (
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-[var(--gold)]/10 text-[var(--gold)] text-xs rounded-full">
                {beanTypes.find(b => b.value === beanType)?.label} <button onClick={() => setBeanType("")}><X size={12} /></button>
              </span>
            )}
          </div>
        )}

        {/* Product Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-[var(--charcoal-light)] rounded-lg overflow-hidden animate-pulse">
                <div className="aspect-square bg-[var(--charcoal)]" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-[var(--charcoal)] rounded w-3/4" />
                  <div className="h-3 bg-[var(--charcoal)] rounded w-1/2" />
                  <div className="h-4 bg-[var(--charcoal)] rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-[var(--cream-muted)] text-lg mb-4">No products found</p>
            <button onClick={clearFilters} className="btn-secondary">
              Clear Filters
            </button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map((product) => (
                <Link
                  key={product.id}
                  to={`/product/${product.slug}`}
                  className="group block bg-[var(--charcoal-light)] rounded-lg overflow-hidden border border-[var(--cream-muted)]/8 hover:border-[var(--gold)]/30 transition-all duration-400 hover:-translate-y-1"
                >
                  <div className="aspect-square overflow-hidden bg-[var(--charcoal-light)] relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {product.badge && (
                      <span className={`absolute top-3 left-3 text-[10px] uppercase tracking-wider px-2 py-1 rounded ${
                        product.badge === "sale" ? "bg-red-500/80 text-white" :
                        product.badge === "bestseller" ? "bg-[var(--gold)]/80 text-[var(--charcoal)]" :
                        "bg-[var(--green)]/80 text-white"
                      }`}>
                        {product.badge}
                      </span>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="text-[var(--cream)] text-sm font-medium line-clamp-2 group-hover:text-[var(--gold)] transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-xs text-[var(--cream-muted)] mt-1 uppercase tracking-wider">
                      {product.origin} &middot; {product.roastLevel}
                    </p>
                    <div className="flex items-center gap-2 mt-3">
                      <span className="text-[var(--gold)] font-semibold">
                        {Number(product.price).toFixed(2)} kr
                      </span>
                      {product.comparePrice && (
                        <span className="text-[var(--cream-muted)] line-through text-xs">
                          {Number(product.comparePrice).toFixed(2)} kr
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-12">
                <button
                  onClick={() => setPage(Math.max(1, page - 1))}
                  disabled={page === 1}
                  className="px-4 py-2 bg-[var(--charcoal-light)] rounded-lg text-sm text-[var(--cream-muted)] hover:text-[var(--gold)] disabled:opacity-30 transition-colors border border-[var(--cream-muted)]/10"
                >
                  Previous
                </button>
                {Array.from({ length: totalPages }).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setPage(i + 1)}
                    className={`w-9 h-9 rounded-lg text-sm transition-colors ${
                      page === i + 1
                        ? "bg-[var(--gold)] text-[var(--charcoal)]"
                        : "bg-[var(--charcoal-light)] text-[var(--cream-muted)] hover:text-[var(--gold)] border border-[var(--cream-muted)]/10"
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => setPage(Math.min(totalPages, page + 1))}
                  disabled={page === totalPages}
                  className="px-4 py-2 bg-[var(--charcoal-light)] rounded-lg text-sm text-[var(--cream-muted)] hover:text-[var(--gold)] disabled:opacity-30 transition-colors border border-[var(--cream-muted)]/10"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>

      <Footer />
    </main>
  );
}
