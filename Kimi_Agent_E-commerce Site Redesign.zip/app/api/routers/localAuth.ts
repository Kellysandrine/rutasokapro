import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { localUsers } from "@db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.LOCAL_AUTH_SECRET || "rutasoka-local-auth-secret-key-2024";

export const localAuthRouter = createRouter({
  register: publicQuery
    .input(z.object({
      username: z.string().min(3).max(100),
      email: z.string().email(),
      password: z.string().min(6),
      displayName: z.string().optional(),
    }))
    .mutation(async ({ input }: { input: any }) => {
      const db = getDb();

      const existing = await db
        .select()
        .from(localUsers)
        .where(eq(localUsers.username, input.username))
        .limit(1);

      if (existing[0]) {
        throw new Error("Username already taken");
      }

      const existingEmail = await db
        .select()
        .from(localUsers)
        .where(eq(localUsers.email, input.email))
        .limit(1);

      if (existingEmail[0]) {
        throw new Error("Email already registered");
      }

      const passwordHash = await bcrypt.hash(input.password, 10);

      const result = await db.insert(localUsers).values({
        username: input.username,
        email: input.email,
        passwordHash,
        displayName: input.displayName || input.username,
      });

      const userId = Number(result[0].insertId);
      const token = jwt.sign({ userId, type: "local" }, JWT_SECRET, { expiresIn: "7d" });

      return {
        token,
        user: {
          id: userId,
          username: input.username,
          email: input.email,
          displayName: input.displayName || input.username,
          role: "user",
        },
      };
    }),

  login: publicQuery
    .input(z.object({
      username: z.string(),
      password: z.string(),
    }))
    .mutation(async ({ input }: { input: any }) => {
      const db = getDb();

      const user = await db
        .select()
        .from(localUsers)
        .where(eq(localUsers.username, input.username))
        .limit(1);

      if (!user[0]) {
        throw new Error("Invalid username or password");
      }

      const valid = await bcrypt.compare(input.password, user[0].passwordHash);
      if (!valid) {
        throw new Error("Invalid username or password");
      }

      const token = jwt.sign({ userId: user[0].id, type: "local" }, JWT_SECRET, { expiresIn: "7d" });

      return {
        token,
        user: {
          id: user[0].id,
          username: user[0].username,
          email: user[0].email,
          displayName: user[0].displayName,
          role: user[0].role,
        },
      };
    }),

  me: publicQuery.query(async ({ ctx }: { ctx: any }) => {
    const req = ctx.req;
    const authHeader = req.headers.get("x-local-auth-token");

    if (!authHeader) return null;

    try {
      const decoded = jwt.verify(authHeader, JWT_SECRET) as { userId: number; type: string };
      if (decoded.type !== "local") return null;

      const db = getDb();
      const user = await db
        .select()
        .from(localUsers)
        .where(eq(localUsers.id, decoded.userId))
        .limit(1);

      if (!user[0]) return null;

      return {
        id: user[0].id,
        username: user[0].username,
        email: user[0].email,
        displayName: user[0].displayName,
        role: user[0].role,
        name: user[0].displayName || user[0].username,
      };
    } catch {
      return null;
    }
  }),
});
