import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { cartItems, products } from "@db/schema";
import { eq, and } from "drizzle-orm";

export const cartRouter = createRouter({
  get: publicQuery
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ input }: { input: { sessionId: string } }) => {
      const db = getDb();
      const items = await db
        .select({
          id: cartItems.id,
          sessionId: cartItems.sessionId,
          productId: cartItems.productId,
          quantity: cartItems.quantity,
          product: products,
        })
        .from(cartItems)
        .innerJoin(products, eq(cartItems.productId, products.id))
        .where(eq(cartItems.sessionId, input.sessionId));

      return items.map((item: any) => ({
        ...item,
        lineTotal: Number(item.product.price) * item.quantity,
      }));
    }),

  add: publicQuery
    .input(z.object({
      sessionId: z.string(),
      productId: z.number(),
      quantity: z.number().default(1),
    }))
    .mutation(async ({ input }: { input: { sessionId: string; productId: number; quantity: number } }) => {
      const db = getDb();
      
      const existing = await db
        .select()
        .from(cartItems)
        .where(and(
          eq(cartItems.sessionId, input.sessionId),
          eq(cartItems.productId, input.productId)
        ))
        .limit(1);

      if (existing[0]) {
        const newQty = existing[0].quantity + input.quantity;
        await db
          .update(cartItems)
          .set({ quantity: newQty })
          .where(eq(cartItems.id, existing[0].id));
        return { ...existing[0], quantity: newQty };
      }

      const result = await db.insert(cartItems).values({
        sessionId: input.sessionId,
        productId: input.productId,
        quantity: input.quantity,
      });

      return { id: Number(result[0].insertId), ...input };
    }),

  updateQuantity: publicQuery
    .input(z.object({
      sessionId: z.string(),
      itemId: z.number(),
      quantity: z.number(),
    }))
    .mutation(async ({ input }: { input: { sessionId: string; itemId: number; quantity: number } }) => {
      const db = getDb();
      await db
        .update(cartItems)
        .set({ quantity: input.quantity })
        .where(and(
          eq(cartItems.id, input.itemId),
          eq(cartItems.sessionId, input.sessionId)
        ));
      return { success: true };
    }),

  remove: publicQuery
    .input(z.object({
      sessionId: z.string(),
      itemId: z.number(),
    }))
    .mutation(async ({ input }: { input: { sessionId: string; itemId: number } }) => {
      const db = getDb();
      await db
        .delete(cartItems)
        .where(and(
          eq(cartItems.id, input.itemId),
          eq(cartItems.sessionId, input.sessionId)
        ));
      return { success: true };
    }),

  clear: publicQuery
    .input(z.object({ sessionId: z.string() }))
    .mutation(async ({ input }: { input: { sessionId: string } }) => {
      const db = getDb();
      await db.delete(cartItems).where(eq(cartItems.sessionId, input.sessionId));
      return { success: true };
    }),
});
