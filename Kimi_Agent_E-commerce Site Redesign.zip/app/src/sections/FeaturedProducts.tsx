import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { trpc } from "@/providers/trpc";

export default function FeaturedProducts() {
  const { data } = trpc.product.list.useQuery({ limit: 4, sort: "name" });
  const products = data?.items || [];

  return (
    <section className="py-24 bg-[var(--charcoal)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="font-display text-3xl sm:text-4xl text-[var(--cream)] mb-2">
              Our Collection
            </h2>
            <p className="text-[var(--cream-muted)] text-sm">
              Discover our range of premium East African coffees
            </p>
          </div>
          <Link
            to="/shop"
            className="hidden sm:flex items-center gap-2 text-[var(--gold)] text-sm hover:gap-3 transition-all duration-300"
          >
            View All <ArrowRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Link
              key={product.id}
              to={`/product/${product.slug}`}
              className="group block bg-[var(--charcoal-light)] rounded-lg overflow-hidden border border-[var(--cream-muted)]/8 hover:border-[var(--gold)]/30 transition-all duration-400 hover:-translate-y-1"
            >
              <div className="aspect-square overflow-hidden bg-[var(--charcoal-light)]">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-[var(--cream)] text-sm font-medium line-clamp-2 group-hover:text-[var(--gold)] transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-xs text-[var(--cream-muted)] mt-1 uppercase tracking-wider">
                      {product.origin}
                    </p>
                  </div>
                  {product.badge && (
                    <span className={`shrink-0 text-[10px] uppercase tracking-wider px-2 py-0.5 rounded ${
                      product.badge === "sale" ? "bg-red-500/20 text-red-400" :
                      product.badge === "bestseller" ? "bg-[var(--gold)]/20 text-[var(--gold)]" :
                      "bg-[var(--green)]/20 text-[var(--green-bright)]"
                    }`}>
                      {product.badge}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-3">
                  <span className="text-[var(--gold)] font-semibold">
                    {Number(product.price).toFixed(2)} kr
                  </span>
                  {product.comparePrice && (
                    <span className="text-[var(--cream-muted)] line-through text-xs">
                      {Number(product.comparePrice).toFixed(2)} kr
                    </span>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="sm:hidden mt-8 text-center">
          <Link to="/shop" className="btn-secondary">
            View All Products
          </Link>
        </div>
      </div>
    </section>
  );
}
