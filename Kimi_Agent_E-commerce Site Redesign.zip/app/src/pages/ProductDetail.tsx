import { useState } from "react";
import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useCartStore } from "@/store/cartStore";
import { Star, Minus, Plus, Check, Leaf, ArrowLeft, Truck, Shield } from "lucide-react";
import { toast } from "sonner";
import Footer from "@/sections/Footer";

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { data: product, isLoading } = trpc.product.getBySlug.useQuery(
    { slug: slug || "" },
    { enabled: !!slug }
  );
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<"description" | "origin" | "brewing">("description");
  const addMutation = trpc.cart.add.useMutation();
  const sessionId = useCartStore((s) => s.sessionId);
  const utils = trpc.useUtils();

  const handleAddToCart = () => {
    if (!product) return;
    addMutation.mutate(
      { sessionId, productId: product.id, quantity },
      {
        onSuccess: () => {
          utils.cart.get.invalidate({ sessionId });
          toast.success(`${product.name} added to cart`);
          useCartStore.getState().setCartOpen(true);
        },
        onError: () => toast.error("Failed to add to cart"),
      }
    );
  };

  if (isLoading) {
    return (
      <main className="min-h-screen bg-[var(--charcoal)] pt-20 flex items-center justify-center">
        <div className="animate-pulse text-[var(--gold)]">Loading...</div>
      </main>
    );
  }

  if (!product) {
    return (
      <main className="min-h-screen bg-[var(--charcoal)] pt-20 flex items-center justify-center">
        <div className="text-center">
          <p className="text-[var(--cream-muted)] mb-4">Product not found</p>
          <Link to="/shop" className="btn-primary">Back to Shop</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[var(--charcoal)] pt-20">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <Link to="/shop" className="inline-flex items-center gap-2 text-sm text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors">
          <ArrowLeft size={16} /> Back to Shop
        </Link>
      </div>

      {/* Product Hero */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Image */}
          <div className="aspect-square bg-[var(--charcoal-light)] rounded-lg overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Info */}
          <div>
            <div className="flex items-center gap-3 mb-3">
              <span className="text-xs uppercase tracking-wider text-[var(--cream-muted)] bg-[var(--charcoal-light)] px-3 py-1 rounded-full">
                {product.origin}
              </span>
              <span className="text-xs uppercase tracking-wider text-[var(--gold)] bg-[var(--gold)]/10 px-3 py-1 rounded-full capitalize">
                {product.roastLevel}
              </span>
            </div>

            <h1 className="font-display text-3xl sm:text-4xl text-[var(--cream)] mb-2">
              {product.name}
            </h1>

            <div className="flex items-center gap-3 mb-4">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className={i < Math.floor(Number(product.rating)) ? "text-[var(--gold)] fill-[var(--gold)]" : "text-[var(--cream-muted)]/30"}
                  />
                ))}
              </div>
              <span className="text-sm text-[var(--cream-muted)]">
                {product.rating} ({product.reviewCount} reviews)
              </span>
            </div>

            <div className="flex items-center gap-3 mb-6">
              <span className="text-2xl sm:text-3xl text-[var(--gold)] font-semibold">
                {Number(product.price).toFixed(2)} kr
              </span>
              {product.comparePrice && (
                <span className="text-lg text-[var(--cream-muted)] line-through">
                  {Number(product.comparePrice).toFixed(2)} kr
                </span>
              )}
              {product.badge === "sale" && product.comparePrice && (
                <span className="text-xs uppercase tracking-wider bg-red-500/20 text-red-400 px-2 py-1 rounded">
                  Save {Math.round((1 - Number(product.price) / Number(product.comparePrice)) * 100)}%
                </span>
              )}
            </div>

            {/* Certifications */}
            <div className="flex flex-wrap gap-4 mb-6">
              {product.isOrganic && (
                <div className="flex items-center gap-2 text-sm text-[var(--green-bright)]">
                  <Leaf size={16} /> Organic
                </div>
              )}
              {product.isFairTrade && (
                <div className="flex items-center gap-2 text-sm text-[var(--gold)]">
                  <Shield size={16} /> Fair Trade
                </div>
              )}
              {product.is100Arabica && (
                <div className="flex items-center gap-2 text-sm text-[var(--cream-muted)]">
                  <Check size={16} /> 100% Arabica
                </div>
              )}
            </div>

            <p className="text-[var(--cream-muted)] leading-relaxed mb-6">
              {product.shortDescription}
            </p>

            {/* Weight */}
            <div className="mb-6">
              <label className="text-xs uppercase tracking-wider text-[var(--cream-muted)] mb-2 block">
                Weight: {product.weight}
              </label>
            </div>

            {/* Tasting Notes */}
            {product.tastingNotes && (
              <div className="mb-6">
                <label className="text-xs uppercase tracking-wider text-[var(--cream-muted)] mb-2 block">
                  Tasting Notes
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.tastingNotes.split(",").map((note) => (
                    <span
                      key={note}
                      className="px-3 py-1 bg-[var(--charcoal-light)] text-[var(--cream)] text-sm rounded-full border border-[var(--cream-muted)]/10"
                    >
                      {note.trim()}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity + Add to Cart */}
            <div className="flex flex-wrap items-center gap-4 mb-8">
              <div className="flex items-center border border-[var(--cream-muted)]/20 rounded-lg overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-12 flex items-center justify-center text-[var(--cream-muted)] hover:bg-[var(--charcoal-light)] transition-colors"
                >
                  <Minus size={16} />
                </button>
                <span className="w-12 h-12 flex items-center justify-center text-[var(--cream)] font-medium border-x border-[var(--cream-muted)]/20">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-12 flex items-center justify-center text-[var(--cream-muted)] hover:bg-[var(--charcoal-light)] transition-colors"
                >
                  <Plus size={16} />
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                disabled={addMutation.isPending}
                className="btn-primary flex-1 min-w-[200px] disabled:opacity-50"
              >
                {addMutation.isPending ? "Adding..." : "Add to Bag"}
              </button>
            </div>

            {/* Shipping note */}
            <div className="flex items-center gap-2 text-sm text-[var(--cream-muted)]">
              <Truck size={16} />
              Free shipping on orders over 500 kr
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-16 border-t border-[var(--cream-muted)]/10 pt-8">
          <div className="flex gap-6 border-b border-[var(--cream-muted)]/10 mb-6">
            {(["description", "origin", "brewing"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-3 text-sm uppercase tracking-wider transition-colors relative ${
                  activeTab === tab
                    ? "text-[var(--gold)]"
                    : "text-[var(--cream-muted)] hover:text-[var(--cream)]"
                }`}
              >
                {tab === "description" ? "Description" : tab === "origin" ? "Origin Story" : "Brewing Guide"}
                {activeTab === tab && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--gold)]" />
                )}
              </button>
            ))}
          </div>

          <div className="max-w-3xl">
            {activeTab === "description" && (
              <div className="text-[var(--cream-muted)] leading-relaxed space-y-4">
                <p>{product.description}</p>
              </div>
            )}
            {activeTab === "origin" && (
              <div className="text-[var(--cream-muted)] leading-relaxed space-y-4">
                <p>
                  Our {product.origin} coffee comes from carefully selected farms in the region, 
                  where generations of farmers have perfected the art of growing exceptional Arabica coffee. 
                  The unique terroir of this region contributes to the distinctive flavor profile that 
                  makes this coffee truly special.
                </p>
                <p>
                  We work directly with farming cooperatives to ensure fair wages and sustainable 
                  practices. Every purchase supports local communities and helps preserve traditional 
                  coffee-growing methods.
                </p>
              </div>
            )}
            {activeTab === "brewing" && (
              <div className="text-[var(--cream-muted)] leading-relaxed space-y-4">
                <p>
                  <strong className="text-[var(--cream)]">Recommended brewing methods:</strong> Pour-over (V60), 
                  French Press, or Aeropress for best results.
                </p>
                <p>
                  <strong className="text-[var(--cream)]">Grind size:</strong> Medium-fine for pour-over, 
                  coarse for French Press.
                </p>
                <p>
                  <strong className="text-[var(--cream)]">Water temperature:</strong> 92-96°C for optimal extraction.
                </p>
                <p>
                  <strong className="text-[var(--cream)]">Ratio:</strong> 1:16 coffee to water for a balanced cup.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        {(product as any).related && (product as any).related.length > 0 && (
          <div className="mt-16">
            <h2 className="font-display text-2xl text-[var(--cream)] mb-6">
              You May Also Like
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {(product as any).related.map((rp: any) => (
                <Link
                  key={rp.id}
                  to={`/product/${rp.slug}`}
                  className="group block bg-[var(--charcoal-light)] rounded-lg overflow-hidden border border-[var(--cream-muted)]/8 hover:border-[var(--gold)]/30 transition-all duration-300"
                >
                  <div className="aspect-square overflow-hidden">
                    <img src={rp.image} alt={rp.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm text-[var(--cream)] line-clamp-2 group-hover:text-[var(--gold)] transition-colors">{rp.name}</h3>
                    <p className="text-[var(--gold)] text-sm font-medium mt-1">{Number(rp.price).toFixed(2)} kr</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="mt-16">
        <Footer />
      </div>
    </main>
  );
}
