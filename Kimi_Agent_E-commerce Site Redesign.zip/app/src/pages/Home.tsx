import HeroSlideshow from "@/sections/HeroSlideshow";
import FeaturedProducts from "@/sections/FeaturedProducts";
import FounderStory from "@/sections/FounderStory";
import CraftSection from "@/sections/CraftSection";
import SubscriptionCTA from "@/sections/SubscriptionCTA";
import Footer from "@/sections/Footer";

export default function Home() {
  return (
    <main>
      <HeroSlideshow />
      <FeaturedProducts />
      <FounderStory />
      <CraftSection />
      <SubscriptionCTA />
      <Footer />
    </main>
  );
}
