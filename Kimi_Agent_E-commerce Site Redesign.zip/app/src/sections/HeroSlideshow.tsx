import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";

const slides = [
  {
    image: "/hero/slide-1.jpg",
    title: "The Taste of East Africa",
    subtitle: "At Rutasoka, the highlands of East Africa meet our uncompromising quality \u2013 a coffee with vibrant notes of citrus and berries, rounded off with a clean and elegant aftertaste.",
    cta: "Explore Our Range",
    href: "/shop",
  },
  {
    image: "/hero/slide-2.jpg",
    title: "Crafted with Intention",
    subtitle: "Every bean is slow-roasted to perfection, bringing out unique and delicate flavors from selected quality beans sourced directly from East African farmers.",
    cta: "Discover Our Process",
    href: "/about",
  },
  {
    image: "/hero/slide-3.jpg",
    title: "From Origin to Cup",
    subtitle: "Trace the journey of exceptional coffee \u2013 sourced, roasted, and delivered with purpose. Experience the best of East Africa in every sip.",
    cta: "Shop Now",
    href: "/shop",
  },
  {
    image: "/hero/slide-4.jpg",
    title: "A Cup That Makes a Difference",
    subtitle: "We believe in the power of collaboration, where respect for people and nature is united in a common endeavor to create more than just coffee.",
    cta: "Learn Our Story",
    href: "/about",
  },
];

export default function HeroSlideshow() {
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const goTo = useCallback((index: number) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrent(index);
    setTimeout(() => setIsAnimating(false), 800);
  }, [isAnimating]);

  const next = useCallback(() => {
    goTo((current + 1) % slides.length);
  }, [current, goTo]);

  const prev = useCallback(() => {
    goTo((current - 1 + slides.length) % slides.length);
  }, [current, goTo]);

  useEffect(() => {
    const timer = setInterval(next, 6000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <section className="relative w-full h-screen min-h-[600px] overflow-hidden">
      {/* Slides */}
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === current ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#1A1714] via-[#1A1714]/60 to-[#1A1714]/30" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#1A1714]/70 to-transparent" />
          </div>

          {/* Content */}
          <div className="relative z-20 h-full flex items-center">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full">
              <div
                className={`max-w-2xl transition-all duration-1000 ${
                  index === current
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
              >
                <h1 className="font-display text-4xl sm:text-5xl lg:text-7xl font-light text-[var(--cream)] leading-tight mb-4">
                  {slide.title}
                </h1>
                <p className="text-base sm:text-lg text-[var(--cream-muted)] leading-relaxed mb-8 max-w-xl">
                  {slide.subtitle}
                </p>
                <Link to={slide.href} className="btn-primary">
                  {slide.cta}
                </Link>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Arrows */}
      <button
        onClick={prev}
        className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-30 w-12 h-12 rounded-full border border-[var(--cream-muted)]/20 flex items-center justify-center text-[var(--cream-muted)] hover:text-[var(--gold)] hover:border-[var(--gold)] transition-all duration-300 bg-[#1A1714]/30 backdrop-blur-sm"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={next}
        className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-30 w-12 h-12 rounded-full border border-[var(--cream-muted)]/20 flex items-center justify-center text-[var(--cream-muted)] hover:text-[var(--gold)] hover:border-[var(--gold)] transition-all duration-300 bg-[#1A1714]/30 backdrop-blur-sm"
      >
        <ChevronRight size={24} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex items-center gap-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goTo(index)}
            className={`transition-all duration-300 rounded-full ${
              index === current
                ? "w-8 h-2 bg-[var(--gold)]"
                : "w-2 h-2 bg-[var(--cream-muted)]/40 hover:bg-[var(--cream-muted)]/70"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
