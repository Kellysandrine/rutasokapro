import { Link } from "react-router";
import { ArrowRight } from "lucide-react";

export default function FounderStory() {
  return (
    <section className="py-24 bg-[var(--charcoal-light)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="relative">
            <div className="aspect-[3/4] rounded-lg overflow-hidden">
              <img
                src="/about/founder.jpg"
                alt="Rebu Burubwa, Founder of Rutasoka"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-[var(--gold)] text-[var(--charcoal)] p-6 rounded-lg hidden lg:block">
              <p className="font-display text-3xl font-light">2018</p>
              <p className="text-xs uppercase tracking-wider mt-1">Founded</p>
            </div>
          </div>

          <div>
            <span className="text-[var(--gold)] text-xs uppercase tracking-[0.15em] font-body">
              Our Story
            </span>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[var(--cream)] mt-3 mb-6 leading-tight">
              Rebu Burubwa, Rutasoka&apos;s Visionary Founder
            </h2>
            <div className="space-y-4 text-[var(--cream-muted)] leading-relaxed">
              <p>
                After being forced to flee his homeland during unrest, Rebu Burubwa found safety in Sweden. 
                With a strong connection to Congo and a drive to give back, he works to address the 
                challenges in his hometown of Uvira and create a better future.
              </p>
              <p>
                Rutasoka was born from a simple yet powerful idea: that exceptional coffee can be a 
                force for good. By partnering directly with farming communities in East Africa, we ensure 
                fair wages while delivering world-class coffee to your cup.
              </p>
              <p>
                Every bag of Rutasoka coffee supports sustainable farming practices, community development, 
                and the preservation of coffee-growing traditions that have been passed down for generations.
              </p>
            </div>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 mt-8 text-[var(--gold)] hover:gap-3 transition-all duration-300"
            >
              Read More <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
