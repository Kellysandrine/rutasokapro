import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { ShoppingBag, Menu, X, User, Search, LogOut, Shield } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useCartStore } from "@/store/cartStore";
import { trpc } from "@/providers/trpc";

function useCartSync() {
  const sessionId = localStorage.getItem("rutasoka_session_id") || "";
  const { data } = trpc.cart.get.useQuery(
    { sessionId },
    { enabled: !!sessionId, refetchOnWindowFocus: false }
  );
  useEffect(() => {
    if (data) {
      useCartStore.getState().setItems(data as any);
    }
  }, [data]);
}

const navLinks = [
  { label: "Shop", href: "/shop" },
  { label: "Origins", href: "/shop" },
  { label: "Subscriptions", href: "/subscriptions" },
  { label: "About", href: "/about" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const location = useLocation();
  const { user, isAdmin, logout } = useAuth();
  const { toggleCart, items } = useCartStore();

  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 100);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  // Sync cart with server
  useCartSync();

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 h-16 transition-all duration-300 ${
          scrolled
            ? "bg-[#1A1714]/95 backdrop-blur-xl border-b border-[var(--gold)]/10"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-full flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <span className="font-display text-xl tracking-[0.2em] text-[var(--cream)]">
              RUTASOKA
            </span>
            <span className="hidden sm:inline text-[10px] tracking-[0.15em] text-[var(--gold)] uppercase font-body">
              Coffee
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                to={link.href}
                className="relative text-sm tracking-[0.08em] text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors duration-300 group font-body uppercase"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[var(--gold)] transition-all duration-300 group-hover:w-full" />
              </Link>
            ))}
            {isAdmin && (
              <Link
                to="/admin"
                className="relative text-sm tracking-[0.08em] text-[var(--gold)] hover:text-[var(--gold-bright)] transition-colors duration-300 group font-body uppercase flex items-center gap-1"
              >
                <Shield size={14} />
                Admin
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[var(--gold)] transition-all duration-300 group-hover:w-full" />
              </Link>
            )}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3 sm:gap-4">
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors hidden sm:block"
            >
              <Search size={20} />
            </button>

            {user ? (
              <div className="hidden sm:flex items-center gap-2">
                <span className="text-sm text-[var(--cream-muted)]">{user.name}</span>
                <button
                  onClick={logout}
                  className="text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors"
                >
                  <LogOut size={18} />
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                className="hidden sm:block text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors"
              >
                <User size={20} />
              </Link>
            )}

            <button
              onClick={toggleCart}
              className="relative text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors"
            >
              <ShoppingBag size={20} />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[var(--gold)] text-[var(--charcoal)] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors"
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-[#1A1714]/98 backdrop-blur-lg pt-20">
          <nav className="flex flex-col items-center gap-8 p-8">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                to={link.href}
                className="text-2xl font-display text-[var(--cream)] hover:text-[var(--gold)] transition-colors"
              >
                {link.label}
              </Link>
            ))}
            {isAdmin && (
              <Link to="/admin" className="text-2xl font-display text-[var(--gold)] hover:text-[var(--gold-bright)] transition-colors flex items-center gap-2">
                <Shield size={20} /> Admin Dashboard
              </Link>
            )}
            {user ? (
              <button onClick={logout} className="text-lg text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors flex items-center gap-2">
                <LogOut size={18} /> Sign Out
              </button>
            ) : (
              <Link to="/login" className="text-lg text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors">
                Sign In
              </Link>
            )}
          </nav>
        </div>
      )}

      {/* Search Overlay */}
      {searchOpen && (
        <div className="fixed inset-x-0 top-16 z-40 bg-[#1A1714]/95 backdrop-blur-lg p-4">
          <div className="max-w-2xl mx-auto">
            <input
              type="text"
              placeholder="Search coffee, origins..."
              autoFocus
              className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
              onChange={(e) => {
                if (e.target.value.length > 2) {
                  // Navigate to search
                }
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  setSearchOpen(false);
                  window.location.href = `/shop?search=${(e.target as HTMLInputElement).value}`;
                }
              }}
            />
          </div>
        </div>
      )}
    </>
  );
}
