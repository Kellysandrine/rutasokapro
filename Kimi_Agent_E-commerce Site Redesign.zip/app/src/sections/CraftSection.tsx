import { Link } from "react-router";
import { ArrowRight } from "lucide-react";

export default function CraftSection() {
  return (
    <section className="py-24 bg-[var(--charcoal)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="order-2 lg:order-1">
            <span className="text-[var(--gold)] text-xs uppercase tracking-[0.15em] font-body">
              The Craft
            </span>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[var(--cream)] mt-3 mb-6 leading-tight">
              Roasted with Intention
            </h2>
            <div className="space-y-4 text-[var(--cream-muted)] leading-relaxed">
              <p>
                Rutasoka coffee is gently roasted using the slow-roast method. The roasting brings 
                out the unique and delicate flavors from the selected quality beans, which gives a 
                balanced taste and fantastic crema.
              </p>
              <p>
                Our beans are sourced from the highlands of East Africa, where the combination of 
                altitude, soil, and climate creates the perfect conditions for growing exceptional 
                Arabica coffee. Each origin tells a different story through its unique flavor profile.
              </p>
              <p>
                We believe that great coffee starts at the source. That&apos;s why we work directly 
                with farming cooperatives, ensuring fair trade practices and sustainable agriculture 
                that protects both the land and the livelihoods of coffee farmers.
              </p>
            </div>
            <div className="flex flex-wrap gap-6 mt-8">
              <div className="text-center">
                <p className="font-display text-3xl text-[var(--gold)]">100%</p>
                <p className="text-xs text-[var(--cream-muted)] uppercase tracking-wider mt-1">Arabica</p>
              </div>
              <div className="text-center">
                <p className="font-display text-3xl text-[var(--gold)]">Organic</p>
                <p className="text-xs text-[var(--cream-muted)] uppercase tracking-wider mt-1">Certified</p>
              </div>
              <div className="text-center">
                <p className="font-display text-3xl text-[var(--gold)]">Fair</p>
                <p className="text-xs text-[var(--cream-muted)] uppercase tracking-wider mt-1">Trade</p>
              </div>
            </div>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 mt-8 text-[var(--gold)] hover:gap-3 transition-all duration-300"
            >
              Learn More <ArrowRight size={16} />
            </Link>
          </div>

          <div className="order-1 lg:order-2 grid grid-cols-2 gap-4">
            <div className="aspect-[4/5] rounded-lg overflow-hidden">
              <img
                src="/hero/slide-2.jpg"
                alt="Coffee roasting process"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-[4/5] rounded-lg overflow-hidden mt-8">
              <img
                src="/about/craft.jpg"
                alt="Quality control cupping"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
