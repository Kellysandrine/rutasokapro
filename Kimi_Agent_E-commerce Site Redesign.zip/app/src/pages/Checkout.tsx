import { useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useCartStore } from "@/store/cartStore";
import { ArrowLeft, Check, Truck, Package } from "lucide-react";
import { toast } from "sonner";

export default function Checkout() {
  const { items, sessionId, clearCart } = useCartStore();
  const [step, setStep] = useState<"info" | "success">("info");
  const [orderNumber, setOrderNumber] = useState("");
  const [form, setForm] = useState({
    email: "",
    firstName: "",
    lastName: "",
    address: "",
    city: "",
    postalCode: "",
    country: "Sweden",
    notes: "",
  });

  const subtotal = items.reduce((sum, i) => sum + i.lineTotal, 0);
  const shipping = subtotal > 500 ? 0 : 49;
  const total = subtotal + shipping;

  const createOrder = trpc.order.create.useMutation({
    onSuccess: (data) => {
      clearCart();
      setOrderNumber(data.orderNumber);
      setStep("success");
      toast.success("Order placed successfully!");
    },
    onError: (err) => {
      toast.error(err.message || "Failed to place order");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email) {
      toast.error("Please enter your email");
      return;
    }
    createOrder.mutate({
      sessionId,
      customerEmail: form.email,
      customerName: `${form.firstName} ${form.lastName}`.trim(),
      shippingAddress: {
        street: form.address,
        city: form.city,
        postalCode: form.postalCode,
        country: form.country,
      },
      notes: form.notes,
    });
  };

  if (items.length === 0 && step === "info") {
    return (
      <main className="min-h-screen bg-[var(--charcoal)] pt-20 flex items-center justify-center">
        <div className="text-center">
          <Package size={48} className="mx-auto text-[var(--cream-muted)]/30 mb-4" />
          <p className="text-[var(--cream-muted)] mb-4">Your cart is empty</p>
          <Link to="/shop" className="btn-primary">Continue Shopping</Link>
        </div>
      </main>
    );
  }

  if (step === "success") {
    return (
      <main className="min-h-screen bg-[var(--charcoal)] pt-20 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <div className="w-16 h-16 rounded-full bg-[var(--green)]/20 flex items-center justify-center mx-auto mb-6">
            <Check size={32} className="text-[var(--green-bright)]" />
          </div>
          <h1 className="font-display text-3xl text-[var(--cream)] mb-2">
            Thank You!
          </h1>
          <p className="text-[var(--cream-muted)] mb-2">
            Your order has been placed successfully.
          </p>
          <p className="text-[var(--gold)] font-medium mb-6">
            Order: {orderNumber}
          </p>
          <p className="text-[var(--cream-muted)] text-sm mb-8">
            We&apos;ve sent a confirmation email with your order details.
          </p>
          <Link to="/shop" className="btn-primary">
            Continue Shopping
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[var(--charcoal)] pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <Link to="/shop" className="inline-flex items-center gap-2 text-sm text-[var(--cream-muted)] hover:text-[var(--gold)] transition-colors mb-8">
          <ArrowLeft size={16} /> Continue Shopping
        </Link>

        <h1 className="font-display text-3xl text-[var(--cream)] mb-8">Checkout</h1>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <h2 className="text-sm uppercase tracking-wider text-[var(--cream-muted)] mb-4">Contact</h2>
              <input
                type="email"
                placeholder="Email *"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
              />
            </div>

            <div>
              <h2 className="text-sm uppercase tracking-wider text-[var(--cream-muted)] mb-4">Shipping Address</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="First name"
                  value={form.firstName}
                  onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
                />
                <input
                  type="text"
                  placeholder="Last name"
                  value={form.lastName}
                  onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                  className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
                />
              </div>
              <input
                type="text"
                placeholder="Address"
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="w-full mt-4 bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
              />
              <div className="grid sm:grid-cols-3 gap-4 mt-4">
                <input
                  type="text"
                  placeholder="City"
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
                />
                <input
                  type="text"
                  placeholder="Postal code"
                  value={form.postalCode}
                  onChange={(e) => setForm({ ...form, postalCode: e.target.value })}
                  className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
                />
                <input
                  type="text"
                  placeholder="Country"
                  value={form.country}
                  onChange={(e) => setForm({ ...form, country: e.target.value })}
                  className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50"
                />
              </div>
            </div>

            <div>
              <h2 className="text-sm uppercase tracking-wider text-[var(--cream-muted)] mb-4">Notes (optional)</h2>
              <textarea
                placeholder="Special instructions..."
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                rows={3}
                className="w-full bg-[var(--charcoal-light)] text-[var(--cream)] px-4 py-3 rounded-lg border border-[var(--cream-muted)]/20 focus:border-[var(--gold)] focus:outline-none placeholder:text-[var(--cream-muted)]/50 resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={createOrder.isPending}
              className="btn-primary w-full disabled:opacity-50"
            >
              {createOrder.isPending ? "Placing Order..." : `Pay ${total.toFixed(2)} kr`}
            </button>
          </form>

          {/* Order Summary */}
          <div className="bg-[var(--charcoal-light)] rounded-lg p-6 h-fit">
            <h2 className="text-sm uppercase tracking-wider text-[var(--cream-muted)] mb-4">Order Summary</h2>
            <div className="space-y-4 mb-6">
              {items.map((item) => (
                <div key={item.id} className="flex gap-4">
                  <div className="relative">
                    <img src={item.product.image} alt={item.product.name} className="w-16 h-16 object-cover rounded" />
                    <span className="absolute -top-2 -right-2 w-5 h-5 bg-[var(--charcoal)] border border-[var(--cream-muted)]/20 rounded-full flex items-center justify-center text-[10px] text-[var(--cream)]">
                      {item.quantity}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-[var(--cream)]">{item.product.name}</p>
                    <p className="text-xs text-[var(--cream-muted)]">{item.product.weight}</p>
                  </div>
                  <p className="text-sm text-[var(--gold)]">{item.lineTotal.toFixed(2)} kr</p>
                </div>
              ))}
            </div>

            <div className="space-y-2 pt-4 border-t border-[var(--cream-muted)]/10 text-sm">
              <div className="flex justify-between text-[var(--cream-muted)]">
                <span>Subtotal</span>
                <span>{subtotal.toFixed(2)} kr</span>
              </div>
              <div className="flex justify-between text-[var(--cream-muted)]">
                <span className="flex items-center gap-1"><Truck size={14} /> Shipping</span>
                <span>{shipping === 0 ? "Free" : `${shipping.toFixed(2)} kr`}</span>
              </div>
              <div className="flex justify-between text-[var(--cream)] font-medium pt-2 border-t border-[var(--cream-muted)]/10">
                <span>Total</span>
                <span className="text-[var(--gold)] text-lg">{total.toFixed(2)} kr</span>
              </div>
            </div>

            {shipping > 0 && (
              <p className="text-xs text-[var(--cream-muted)]/60 mt-4">
                Add {(500 - subtotal).toFixed(2)} kr more for free shipping
              </p>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
