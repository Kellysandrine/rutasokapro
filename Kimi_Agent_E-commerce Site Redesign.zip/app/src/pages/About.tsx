import { Leaf, Users, Globe, Award } from "lucide-react";
import Footer from "@/sections/Footer";

export default function About() {
  return (
    <main className="min-h-screen bg-[var(--charcoal)] pt-20">
      {/* Hero */}
      <div className="relative h-[50vh] min-h-[400px]">
        <img src="/hero/slide-4.jpg" alt="East African coffee farm" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--charcoal)] via-[var(--charcoal)]/50 to-transparent" />
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <span className="text-[var(--gold)] text-xs uppercase tracking-[0.15em]">Our Story</span>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl text-[var(--cream)] mt-3 max-w-2xl">
              A Cup That Makes a Difference
            </h1>
          </div>
        </div>
      </div>

      {/* Mission */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="font-display text-3xl text-[var(--cream)] mb-6">
            The taste of East Africa - good coffee with a big impact
          </h2>
          <p className="text-[var(--cream-muted)] leading-relaxed text-lg">
            We believe in the power of collaboration, where respect for people and nature is united 
            in a common endeavor to create more than just coffee. Experience the best of East Africa 
            &ndash; fruity and floral flavors from high-altitude farms, grown with care and tradition.
          </p>
          <p className="text-[var(--gold)] font-medium mt-4 text-lg">
            Big taste. Bigger impact.
          </p>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-[var(--charcoal-light)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="font-display text-3xl text-[var(--cream)] text-center mb-12">
            What Drives Us
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Leaf, title: "Sustainability", desc: "Organic farming practices that protect the land for future generations." },
              { icon: Users, title: "Community", desc: "Direct partnerships with farming cooperatives ensuring fair wages." },
              { icon: Globe, title: "Origin", desc: "Single-origin coffees that showcase the unique terroir of East Africa." },
              { icon: Award, title: "Quality", desc: "Slow-roasted to perfection, bringing out delicate and unique flavors." },
            ].map((item) => (
              <div key={item.title} className="text-center">
                <div className="w-14 h-14 rounded-full border border-[var(--gold)]/30 flex items-center justify-center mx-auto mb-4">
                  <item.icon size={24} className="text-[var(--gold)]" />
                </div>
                <h3 className="text-[var(--cream)] font-medium mb-2">{item.title}</h3>
                <p className="text-[var(--cream-muted)] text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="aspect-[3/4] rounded-lg overflow-hidden max-w-md mx-auto lg:mx-0">
              <img src="/about/founder.jpg" alt="Rebu Burubwa" className="w-full h-full object-cover" />
            </div>
            <div>
              <span className="text-[var(--gold)] text-xs uppercase tracking-[0.15em]">Our Founder</span>
              <h2 className="font-display text-3xl sm:text-4xl text-[var(--cream)] mt-3 mb-6">
                Rebu Burubwa
              </h2>
              <div className="space-y-4 text-[var(--cream-muted)] leading-relaxed">
                <p>
                  After being forced to flee his homeland during unrest, Rebu Burubwa found safety in Sweden. 
                  With a strong connection to Congo and a drive to give back, he works to address the 
                  challenges in his hometown of Uvira and create a better future.
                </p>
                <p>
                  Rutasoka was founded on the belief that exceptional coffee can be a catalyst for positive change. 
                  By connecting East African coffee farmers directly with consumers, we create value at every step 
                  of the supply chain.
                </p>
                <p>
                  Today, Rutasoka partners with farming communities across East Africa, helping them access 
                  international markets while maintaining the highest standards of quality and sustainability.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Impact */}
      <section id="impact" className="py-20 bg-[var(--warm-brown)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="font-display text-3xl text-[var(--cream)] mb-12">
            Our Impact in 2025
          </h2>
          <div className="grid sm:grid-cols-3 gap-8">
            {[
              { value: "2,500+", label: "Farming Families Supported" },
              { value: "12", label: "Community Projects Funded" },
              { value: "100%", label: "Fair Trade Certified" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-4xl sm:text-5xl text-[var(--gold)]">{stat.value}</p>
                <p className="text-[var(--cream-muted)] text-sm mt-2">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
